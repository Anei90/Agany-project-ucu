<?php
$con = mysqli_connect("localhost", "id18065804_root", "Webhostingxzx@12", "id18065804_ucud") or die("Couldn't connect to the database!");

?>