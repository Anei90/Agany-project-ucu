


I created a project for managing a company's employee roster. 
Executes in Terminal via CLI. Interaction built with node, express, inquirer. 
Employs a MySQL relational database to hold employee information and Console. 
Table for table presentation,and you can convert the database to MS Excel spreadsheet.

Contributer BY ANEI AGANY THEM BSCS1


